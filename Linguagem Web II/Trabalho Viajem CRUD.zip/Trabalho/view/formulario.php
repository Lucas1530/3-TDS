<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD de Viagem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Cadastro de Viagem</h2>
    <form action="index.php" method="POST">
        <div class="mb-3">
            <label for="continente" class="form-label">Continente</label>
            <select id="continente" name="continente_id" class="form-select" required>
                <option value="">Selecione o continente</option>
                <?php
                foreach ($continentes as $continente) {
                    echo "<option value='{$continente['id']}'>{$continente['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="transporte" class="form-label">Transporte</label>
            <select id="transporte" name="transporte_id" class="form-select" required>
                <option value="">Selecione o transporte</option>
                <?php
                if (!empty($transportes)) {
                    foreach ($transportes as $transporte) {
                        echo "<option value='{$transporte['id']}'>{$transporte['nome']}</option>";
                    }
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="pais" class="form-label">País de Destino</label>
            <input type="text" id="pais" name="pais_destino" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Cadastrar Viagem</button>
    </form>

    <h2 class="mt-5">Viagens Cadastradas</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Continente</th>
                <th>Transporte</th>
                <th>País de Destino</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($viagens as $viagem) {
                echo "<tr>
                        <td>{$viagem['continente']}</td>
                        <td>{$viagem['transporte']}</td>
                        <td>{$viagem['pais_destino']}</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
