<?php
class ViagemModel {

    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getContinentes() {
        $query = "SELECT * FROM continentes";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function getTransportes($continente_id) {
        $query = "SELECT * FROM transportes WHERE continente_id = :continente_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':continente_id', $continente_id);
        $stmt->execute();
        return $stmt;
    }

    public function inserirViagem($continente_id, $transporte_id, $pais_destino) {
        $query = "INSERT INTO viagens (continente_id, transporte_id, pais_destino) VALUES (:continente_id, :transporte_id, :pais_destino)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':continente_id', $continente_id);
        $stmt->bindParam(':transporte_id', $transporte_id);
        $stmt->bindParam(':pais_destino', $pais_destino);
        return $stmt->execute();
    }

    public function listarViagens() {
        $query = "SELECT v.id, c.nome AS continente, t.nome AS transporte, v.pais_destino 
                  FROM viagens v
                  JOIN continentes c ON v.continente_id = c.id
                  JOIN transportes t ON v.transporte_id = t.id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
?>
