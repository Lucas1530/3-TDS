<?php
session_start(); // Inicia a sessão para armazenar mensagens de erro e sucesso

include_once 'config.php'; 
include_once 'ViagemController.php';

$controller = new ViagemController($pdo);

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Valida e sanitiza os dados recebidos do formulário
    $continente_id = isset($_POST['continente_id']) ? filter_var($_POST['continente_id'], FILTER_SANITIZE_NUMBER_INT) : null;
    $transporte_id = isset($_POST['transporte_id']) ? filter_var($_POST['transporte_id'], FILTER_SANITIZE_NUMBER_INT) : null;
    $pais_destino = isset($_POST['pais_destino']) ? filter_var($_POST['pais_destino'], FILTER_SANITIZE_STRING) : null;

    // Verifica se todos os campos obrigatórios foram preenchidos
    if (!$continente_id || !$transporte_id || empty($pais_destino)) {
        $_SESSION['msg'] = "<div class='alert alert-danger'>Todos os campos são obrigatórios!</div>";
    } else {
        // Registra a viagem no banco de dados
        if ($controller->registrarViagem($continente_id, $transporte_id, $pais_destino)) {
            $_SESSION['msg'] = "<div class='alert alert-success'>Viagem cadastrada com sucesso!</div>";
        } else {
            $_SESSION['msg'] = "<div class='alert alert-danger'>ERRO ao cadastrar viagem. Tente novamente.</div>";
        }
    }
}

// Obtem os continentes e transportes
$continentes = $controller->obterContinentes();
$transportes = [];
if (isset($_POST['continente_id'])) {
    $transportes = $controller->obterTransportes($_POST['continente_id']);
}

// Listando as viagens
$viagens = $controller->listarViagens();

// Exibe a View
include 'formulario.php';
?>
