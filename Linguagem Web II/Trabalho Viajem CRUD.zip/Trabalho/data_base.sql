-- Criação da tabela de continentes
CREATE TABLE continentes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

-- Inserção de dados fixos na tabela continentes
INSERT INTO continentes (nome) VALUES 
('América do Sul'),
('América do Norte'),
('América Central'),
('Europa'),
('Ásia'),
('África');

-- Criação da tabela de transportes
CREATE TABLE transportes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    continente_id INT,
    FOREIGN KEY (continente_id) REFERENCES continentes(id)
);

-- Inserção de dados fixos na tabela transportes
INSERT INTO transportes (nome, continente_id) VALUES
('Avião', 1), -- América do Sul
('Avião', 2), -- América do Norte
('Avião', 3), -- América Central
('Avião', 4), -- Europa
('Carro', 4), -- Europa
('Avião', 5), -- Ásia
('Carro', 5), -- Ásia
('Barco', 6), -- África
('Avião', 6); -- África

-- Criação da tabela de viagens
CREATE TABLE viagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    continente_id INT,
    transporte_id INT,
    pais_destino VARCHAR(100) NOT NULL,
    FOREIGN KEY (continente_id) REFERENCES continentes(id),
    FOREIGN KEY (transporte_id) REFERENCES transportes(id)
);
