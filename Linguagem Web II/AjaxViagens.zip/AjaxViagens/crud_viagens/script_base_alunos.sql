/* TABELA continentes */
CREATE TABLE continentes (
  id INT AUTO_INCREMENT NOT NULL, 
  nome VARCHAR(70) NOT NULL, 
  CONSTRAINT pk_continentes PRIMARY KEY (id) 
);

/* INSERTs continentes */
INSERT INTO continentes (nome) VALUES ('África');
INSERT INTO continentes (nome) VALUES ('América');
INSERT INTO continentes (nome) VALUES ('Ásia');
INSERT INTO continentes (nome) VALUES ('Europa');


/* TABELA viagens */
CREATE TABLE viagens (
  id INT AUTO_INCREMENT NOT NULL, 
  nome_passageiro VARCHAR(70) NOT NULL, 
  idade INT NOT NULL,
  id_continente INT NOT NULL, 
  pais VARCHAR(70) NOT NULL, 
  CONSTRAINT pk_viagens PRIMARY KEY (id)
);

/* Adicionando a chave estrangeira para o continente */
ALTER TABLE viagens ADD CONSTRAINT fk_continente FOREIGN KEY (id_continente) REFERENCES continentes (id);
