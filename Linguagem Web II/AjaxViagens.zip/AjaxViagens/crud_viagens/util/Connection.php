<?php

require_once(__DIR__ . "/config.php");
include_once(__DIR__ . '/../dao/ViagemDao.php');


//Arquivo Connection.php
class Connection {
    private static $conn;

    public static function getConnection() {
        if (!isset(self::$conn)) {
            try {
                self::$conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASSWORD);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->exec("SET NAMES utf8");
            } catch (PDOException $e) {
                die("Erro ao conectar na base de dados: " . $e->getMessage());
            }
        }
        return self::$conn;
    }
}
