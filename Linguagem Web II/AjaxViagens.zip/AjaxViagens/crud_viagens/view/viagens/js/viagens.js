

function detalhes(idViagem) {
    alert(idViagem);
    //Implementar a requisição AJAX
}