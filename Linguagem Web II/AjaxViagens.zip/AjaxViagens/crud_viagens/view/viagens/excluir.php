<?php
# Página para excluir uma viagem

require_once(__DIR__ . "/../../controller/ViagemController.php");

$id = isset($_GET['id']) && is_numeric($_GET['id']) ? trim($_GET['id']) : 0;

if ($id) {
    // Instanciar o controlador de Viagem
    $viagemCont = new ViagemController();
    
    // Chamar o método excluir do controller
    $erro = $viagemCont->excluir($id);
    
    // Verificar se houve algum erro ao excluir
    if ($erro) {
        // Caso a exclusão tenha sido bem-sucedida, redireciona
        header("Location: listar.php?msg=Viagem excluída com sucesso!");
        exit;
    } else {
        // Caso tenha ocorrido um erro, exibe a mensagem
        echo "Erro ao excluir a viagem: " . implode("<br>", $erros);
        echo "<a href='listar.php'>Voltar</a>";
    }
} else {
    echo "Viagem não encontrada!<br>";
    echo "<a href='listar.php'>Voltar</a>";
}
?>
