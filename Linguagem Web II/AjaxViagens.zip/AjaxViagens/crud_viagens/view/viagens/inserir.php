
<?php

include_once(__DIR__ . "/../../model/Viagem.php");
include_once(__DIR__ . "/../../model/Continente.php");
include_once(__DIR__ . "/../../controller/ViagemController.php");

$msgErro = "";
$viagem = null;

// Verifica se os dados foram enviados via POST
if (isset($_POST['nome_passageiro'])) {
    // Capturando e validando os dados do formulário
    $nome_passageiro = trim($_POST['nome_passageiro']) ? trim($_POST['nome_passageiro']) : null;
    $idade = is_numeric($_POST['idade']) && $_POST['idade'] > 0 ? $_POST['idade'] : null;  // Garantir que a idade seja um número positivo
    $continente = $_POST['continente'];
    $pais = trim($_POST['pais']) ? trim($_POST['pais']) : null;

    // Validando os campos obrigatórios
    if (!$nome_passageiro) {
        $msgErro .= "Nome do passageiro é obrigatório.<br>";
    }

    if (!$idade) {
        $msgErro .= "Idade inválida. Informe uma idade válida.<br>";
    }

    if (!$continente) {
        $msgErro .= "Selecione um continente.<br>";
    }

    if (!$pais) {
        $msgErro .= "Informe o país.<br>";
    }

    // Se não houver erros, cria a viagem
    if (!$msgErro) {
        // Criando o objeto viagem
        $viagem = new Viagem();
        $viagem->setNome($nome_passageiro);
        $viagem->setIdade($idade);
        $viagem->setPais($pais);

        // Setando o continente, se selecionado
        if ($continente) {
            $continenteObj = new Continente();
            $continenteObj->setId($continente);
            $viagem->setContinente($continenteObj);
        }

        // Chamando o controller para inserir a viagem
        $viagemCont = new ViagemController();
        $erros = $viagemCont->inserir($viagem);

        // Se não houver erros ao inserir, redireciona
        if ($erros) {
            header("Location: listar.php");
            exit; 
        } else {
            $msgErro = $erros;
        }
    }
}

include("form.php");

?>
