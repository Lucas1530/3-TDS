<?php

include_once(__DIR__ . "/../../model/Viagem.php");
include_once(__DIR__ . "/../../model/Continente.php");
include_once(__DIR__ . "/../../controller/ViagemController.php");
include_once(__DIR__ . "/../../service/ViagemService.php");

$msgErro = "";
$viagem = null;

$viagemCont = new ViagemController();
$viagemService = new ViagemService();

if (isset($_POST['nome_passageiro'])) {
    // Capturando os dados do formulário
    $nome_passageiro = trim($_POST['nome_passageiro']) ? trim($_POST['nome_passageiro']) : null;
    $pais = trim($_POST['pais']) ? trim($_POST['pais']) : null;
    $idade = is_numeric($_POST['idade']) && $_POST['idade'] > 0 ? $_POST['idade'] : null;  // Garantir que a idade seja um número positivo
    $continente = $_POST['continente'];
    $idViagem = $_POST['id'];

    // Criando o objeto viagem
    $viagem = new Viagem();
    $viagem->setNome($nome_passageiro);
    $viagem->setPais($pais);
    $viagem->setIdade($idade);

    if ($continente) {
        $continenteObj = new Continente();
        $continenteObj->setId($continente);
        $viagem->setContinente($continenteObj);
    } else {
        $viagem->setContinente(null);
    }

    $viagem->setId($idViagem);

    // Validando os dados da viagem
    $erros = $viagemService->validarDados($viagem);

    if (count($erros) <= 0) {
        // Se não houver erros, chamar o controller para inserir ou atualizar
        $viagemCont->alterar($viagem);
        header("location: listar.php");
    } else {
        // Se houver erros, mostrar a mensagem de erro
        $msgErro = implode("<br>", $erros);
    }
} else {
    // Carregar dados da viagem para edição
    $idViagem = 0;
    if (isset($_GET['id']))
        $idViagem = $_GET['id'];

    if ($idViagem) {
        // Carregar os dados da viagem
        $viagem = $viagemCont->buscarPorId($idViagem);
    } else {
        echo "ID da viagem é inválido";
        echo "<a href='listar.php'>Voltar</a>";
        exit;
    }
}

include("form.php");

?>
