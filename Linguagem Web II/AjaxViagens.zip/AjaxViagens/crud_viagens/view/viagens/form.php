<?php
// Buscar os continentes para exibir no select
include_once(__DIR__ . "/../../controller/ContinenteController.php");
$continenteCont = new ContinenteController();
$continentes = $continenteCont->listar();

include_once(__DIR__ . "/../include/header.php"); // Incluindo o header da página
?>

<h3>Cadastrar Viagem</h3>

<div class="row">
    <div class="col-6">
        <!-- Formulário de cadastro de viagem -->
        <form id="formViagem" method="POST">
        
            <!-- Nome do passageiro -->
            <div>
                <label class="form-label" for="txtNomePassageiro">Nome do Passageiro</label>
                <input class="form-control" type="text" placeholder="Informe o nome do passageiro"
                    name="nome_passageiro" id="txtNomePassageiro" maxlength="70"
                    value="<?= $viagem != null ? $viagem->getNome() : "" ?>"> <!-- Preenche se existir a variável $viagem -->
            </div>
            <br>

            <!-- Idade -->
            <div>
                <label class="form-label" for="txtIdade">Idade</label>
                <input class="form-control" type="number" placeholder="Informe a idade"
                    name="idade" id="txtIdade"
                    value="<?= $viagem != null ? $viagem->getIdade() : "" ?>"> <!-- Preenche se existir a variável $viagem -->
            </div>
            <br>

            <!-- Continente -->
            <div>
                <label class="form-label" for="selContinente">Continente</label>
                <select class="form-select" name="continente" id="selContinente">
                    <option value="">Selecione o Continente</option>
                    <!-- Exibe os continentes com a verificação para o continente selecionado -->
                    <?php foreach ($continentes as $c): ?>
                        <option value="<?= $c->getId() ?>"
                            <?= $viagem != null && $viagem->getContinente() != null && $viagem->getContinente()->getId() == $c->getId() ? 'selected' : '' ?>>
                            <?= $c->getNome() ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <br>
            <!-- País -->
            <div>
                <label class="form-label" for="txtPais">País</label>
                <input class="form-control" type="text" placeholder="Informe o país"
                    name="pais" id="txtPais"
                    value="<?= $viagem != null ? $viagem->getPais() : "" ?>"> <!-- Preenche se existir a variável $viagem -->
            </div>
            <br>
            <br>

            <!-- ID da viagem (se existir) -->
            <input type="hidden" name="id" value="<?= $viagem != null ? $viagem->getId() : "" ?>">

            <div class="d-flex">
                <input type="submit" class="btn btn-dark me-2" value="Gravar" />
                <a type="button" class="btn btn-outline-dark" href="listar.php">Voltar</a>
                <a href="https://docs.google.com/document/d/1grAmR1iYA3uZYVvOiHaY_muiL0-5rr-6eGbAK9s6YBA/edit?usp=sharing" 
                class="btn btn-outline-info ms-2" target="_blank">Manual Geografia</a>
            </div>
        </form>
    </div>

    <div class="col-6">
        <!-- Mensagens de erro, caso existam -->
        <?php if ($msgErro): ?>
            <div class="alert alert-info">
                <?= $msgErro ?>
            </div>
        <?php endif; ?>
    </div>
    <br>
</div>

<?php
// Incluindo o footer da página
include_once(__DIR__ . "/../include/footer.php");
?>