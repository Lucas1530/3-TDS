<?php
// Incluindo o controlador para pegar a lista de viagens
include_once(__DIR__ . "/../../controller/ViagemController.php");

// Criando uma instância do controlador
$viagemController = new ViagemController();

// Obtendo a lista de viagens do controlador
$viagens = $viagemController->listar();

// Inclusão do HTML do header
include_once(__DIR__ . "/../include/header.php");
?>

<br>
<!-- Centralizando a imagem -->
<div class="text-center">
    <img src="../../img/Imagem Centro.png" alt="Imagem de Viagens" class="img-fluid" style="max-width: 45%; height: auto;">
</div>
<div class="content-container">
    <h2 class="text-center">Listagem de Viagens</h2>
    <br>

    <table class="table table-hover table-bordered mt-2">
        <!-- Cabeçalho da tabela -->
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Idade</th>
            <th>Continente</th>
            <th>País</th>
            <th></th>
            <th></th>
        </tr>

        <!-- Dados da tabela -->
        <?php foreach($viagens as $viagem): ?> 
            <tr>
                <td>
                    <button type="button" class="btn btn-warning" onclick="detalhes(<?= $viagem->getId(); ?>)"><?= $viagem->getId(); ?></button>
                </td>
                <td><?= $viagem->getNome(); ?></td>
                <td><?= $viagem->getIdade(); ?></td>
                <td><?= $viagem->getContinente()->getNome(); ?></td>
                <td><?= $viagem->getPais(); ?></td>
                <td>
                    <!-- Imagem de editar -->
                    <a href="alterar.php?id=<?= $viagem->getId(); ?>">
                        <img src="../../img/btn_editar.png" alt="Alterar" style="width: 40px; height: auto;">
                    </a>
                </td>

                <td>
                    <!-- Imagem de excluir -->
                    <a href="excluir.php?id=<?= $viagem->getId(); ?>" 
                        onclick="return confirm('Confirma a exclusão da viagem?');">
                        <img src="../../img/btn_excluir.png" alt="Excluir" style="width: 40px; height: auto;">
                    </a>
                </td>
            </tr>
        <?php endforeach; ?> 

    </table>

</div>
<a type="button" class="btn btn-outline-primary" href="inserir.php">Inserir</a>

<div id="divDetalhes" style="border: solid 1px;">
    Exibir os detalhes da viagem clicada aqui!

</div>

<script src="js/viagens.js"></script>

<?php
    // Inclusão do HTML do footer
    include_once(__DIR__ . "/../include/footer.php");
?>
