<?php

// Inclua outros arquivos necessários
include_once(__DIR__ . "/../dao/ViagemDao.php");

class ViagemController {

    // Método para listar as viagens
    public function listar() {
        try {
            $viagemDao = new ViagemDao();
            return $viagemDao->list();
        } catch (Exception $e) {
            echo "Erro ao listar viagens: " . $e->getMessage();
            return [];
        }
    }

    // Método para buscar viagem por ID
    public function buscarPorId($id) {
        try {
            $viagemDao = new ViagemDao();
            return $viagemDao->findById($id);
        } catch (Exception $e) {
            echo "Erro ao buscar viagem: " . $e->getMessage();
            return null;
        }
    }

    // Método para inserir uma nova viagem
    public function inserir(Viagem $viagem) {
        try {
            $viagemDao = new ViagemDao();
            if ($viagemDao->insert($viagem)) {
                return true; // Sucesso
            } else {
                echo "Erro ao inserir viagem.";
                return false;
            }
        } catch (Exception $e) {
            echo "Erro ao inserir viagem: " . $e->getMessage();
            return false;
        }
    }

    // Método para alterar os dados de uma viagem
    public function alterar(Viagem $viagem) {
        try {
            $viagemDao = new ViagemDao();
            if ($viagemDao->update($viagem)) {
                return true; // Sucesso
            } else {
                echo "Erro ao alterar viagem.";
                return false;
            }
        } catch (Exception $e) {
            echo "Erro ao alterar viagem: " . $e->getMessage();
            return false;
        }
    }

    // Método para excluir uma viagem
    public function excluir($id) {
        try {
            $viagemDao = new ViagemDao();
            if ($viagemDao->delete($id)) {
                return true; // Sucesso
            } else {
                echo "Erro ao excluir viagem.";
                return false;
            }
        } catch (Exception $e) {
            echo "Erro ao excluir viagem: " . $e->getMessage();
            return false;
        }
    }
}
?>
