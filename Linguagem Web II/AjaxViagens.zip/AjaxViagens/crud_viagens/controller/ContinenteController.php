<?php

// Inclua outros arquivos necessários
include_once(__DIR__ . "/../dao/ContinenteDao.php");

class ContinenteController {

    // Método para listar os continentes
    public function listar() {
        try {
            $contDao = new ContinenteDao();
            $continentes = $contDao->list();
            return $continentes;
        } catch (Exception $e) {
            // Log de erro ou mensagem informativa
            echo "Erro ao listar continentes: " . $e->getMessage();
            return [];
        }
    }
}
?>
