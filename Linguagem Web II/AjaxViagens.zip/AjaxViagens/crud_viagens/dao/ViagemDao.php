<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Viagem.php");


class ViagemDao {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();        
    }

    public function update(Viagem $viagem) {
        $sql = "UPDATE viagens 
                SET nome_passageiro = :nome_passageiro, 
                    idade = :idade, 
                    pais = :pais, 
                    id_continente = :id_continente 
                WHERE id = :id";
        
        $stm = $this->conn->prepare($sql);
        
        // Bind dos parâmetros
        $stm->bindParam(':nome_passageiro', $viagem->getNome());
        $stm->bindParam(':idade', $viagem->getIdade());
        $stm->bindParam(':pais', $viagem->getPais());
        $stm->bindParam(':id_continente', $viagem->getContinente()->getId());
        $stm->bindParam(':id', $viagem->getId());  // Para identificar qual viagem deve ser alterada
    
        // Executa a consulta e retorna se foi bem-sucedida
        return $stm->execute();
    }
    
    public function delete($id) {
        $sql = "DELETE FROM viagens WHERE id = :id";
        
        $stm = $this->conn->prepare($sql);
        
        // Bind do parâmetro
        $stm->bindParam(':id', $id);
        
        // Executa a consulta e retorna se foi bem-sucedida
        return $stm->execute();
    }
    
    public function list() {
        $sql = "SELECT v.id, v.nome_passageiro, v.idade, v.pais, 
                       c.id AS continente_id, c.nome AS continente_nome
                FROM viagens v
                JOIN continentes c ON v.id_continente = c.id";
    
        $stm = $this->conn->prepare($sql);
        $stm->execute();
    
        $resultados = $stm->fetchAll(PDO::FETCH_ASSOC);
    
        $viagens = $this->mapViagens($resultados);
    
        return $viagens;
    }

    public function findById(int $id) {
        $sql = "SELECT v.id, v.nome_passageiro, v.idade, v.pais, 
                       c.id AS continente_id, c.nome AS continente_nome
                FROM viagens v
                JOIN continentes c ON v.id_continente = c.id
                WHERE v.id = ?";
    
        $stm = $this->conn->prepare($sql);
        $stm->execute([$id]);
    
        $resultados = $stm->fetchAll(PDO::FETCH_ASSOC);
    
        $viagens = $this->mapViagens($resultados);
    

        if($viagens)
            return $viagens[0];

        return null;
    }
    
    private function mapViagens(array $result) {
        $viagens = array();

        foreach($result as $reg) {
            $viagem = new Viagem();
            $viagem->setId($reg['id']);
            $viagem->setNome($reg['nome_passageiro']); // Nome do passageiro
            $viagem->setIdade($reg['idade']);
            $viagem->setPais($reg['pais']); // País
            
            // Aqui a coluna 'id_continente' será mapeada com a classe Continente
            $continente = new Continente(); // Assumindo que há um método para pegar o continente pelo ID
            $continente->setId($reg['continente_id']);
            $continente->setNome($reg['continente_nome']);
            $viagem->setContinente($continente);

            array_push($viagens, $viagem);
        }

        return $viagens;
    }

    public function insert(Viagem $viagem) {
        $sql = "INSERT INTO viagens (nome_passageiro, idade, pais, id_continente) 
                VALUES (:nome_passageiro, :idade, :pais, :id_continente)";
        
        $stm = $this->conn->prepare($sql);
        
        // Bind dos parâmetros
        $stm->bindValue('nome_passageiro', $viagem->getNome());
        $stm->bindValue('idade', $viagem->getIdade());
        $stm->bindValue('pais', $viagem->getPais());
        $stm->bindValue('id_continente', $viagem->getContinente()->getId());
    
        // Executa a consulta e retorna se foi bem-sucedida
        return $stm->execute();
    }
    
    
}

