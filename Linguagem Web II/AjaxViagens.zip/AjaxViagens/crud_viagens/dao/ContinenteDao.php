<?php

include_once(__DIR__ . "/../util/Connection.php");
include_once(__DIR__ . "/../model/Continente.php");

class ContinenteDao {

    private $conn;

    public function __construct() {
        $this->conn = Connection::getConnection();        
    }

    public function list() {
        $sql = "SELECT * FROM continentes"; 

        $stm = $this->conn->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll(PDO::FETCH_ASSOC); // Ajuste: usar FETCH_ASSOC para retorno mais limpo

        return $this->mapContinentes($result);
    }

    private function mapContinentes(array $result) {
        $continentes = [];

        foreach($result as $reg) {
            $continente = new Continente(); // Ajuste: corrigido para criar objetos da classe Continente
            $continente->setId($reg['id']);
            $continente->setNome($reg['nome']);
            $continentes[] = $continente;
        }

        return $continentes;
    }
}
?>
