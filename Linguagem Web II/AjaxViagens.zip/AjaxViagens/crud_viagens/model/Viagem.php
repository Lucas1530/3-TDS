<?php

include_once(__DIR__ . "/Continente.php");

class Viagem {

    private ?int $id;
    private ?string $nome;
    private ?int $idade;
    private ?Continente $continente;
    private ?string $pais;
    



    // Getters and Setters
    public function getId(): ?int {
        return $this->id;
    }

    public function setId(?int $id): self {
        $this->id = $id;
        return $this;
    }

    public function getNome(): ?string {
        return $this->nome;
    }

    public function setNome(?string $nome): self {
        $this->nome = $nome;
        return $this;
    }

    public function getPais(): ?string {
        return $this->pais;
    }

    public function setPais(?string $pais): self {
        $this->pais = $pais;
        return $this;
    }

    public function getContinente(): ?Continente
    {
        return $this->continente;
    }

    public function setContinente(?Continente $continente): self
    {
        $this->continente = $continente;

        return $this;
    }

    public function getIdade(): ?int
    {
        return $this->idade;
    }

    public function setIdade(?int $idade): self
    {
        $this->idade = $idade;

        return $this;

        
    }
}