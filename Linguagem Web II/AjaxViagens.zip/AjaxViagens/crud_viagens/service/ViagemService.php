<?php

class ViagemService {

    public function validarDados(Viagem $viagem) {

        $erros = array();

        // Valida o nome
        if(!$viagem->getNome())
            array_push($erros, "Informe o nome!");

        // Valida a idade, garantindo que não seja negativa
        if(!$viagem->getIdade() || $viagem->getIdade() < 0)
            array_push($erros, "Informe uma idade válida (não pode ser negativa)!");

        // Valida o continente
        if(!$viagem->getContinente())
            array_push($erros, "Informe o continente!");

        // Valida o país
        if(!$viagem->getPais())
            array_push($erros, "Informe o país!");

        return $erros;
    }
}

