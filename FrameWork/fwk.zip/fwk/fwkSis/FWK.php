<?php
require_once "../dao/Conexao.php";

if (isset($_GET['excluir'])) {
    $fwk = new FWK();
    $fwk->excluir($_GET['excluir'], $_GET['tabela']);
}

class FWK
{
    private $conn;

    private function conexao()
    {
        $this->conn = Conexao::conectar();
    }

    private function selecionarBanco()
    {
        $sql = "SELECT DATABASE()";
        $query = $this->conn->query($sql);
        $banco = $query->fetch();
        return $banco[0];
    }

    private function selecionarTabela($t)
    {
        $banco = "Tables_in_" . $this->selecionarBanco();
        $t1 = strtoupper($t);
        $sql = "SHOW TABLES";
        $query = $this->conn->query($sql);
        $tabelas = $query->fetchAll(PDO::FETCH_OBJ);

        foreach ($tabelas as $tabela) {
            $t2 = strtoupper($tabela->$banco);
            if (strcmp($t1, $t2) == 0) {
                return $tabela->$banco;
            }
        }
        return null; // Added return for clarity
    }

    private function selecionarColunas($tabela)
    {
        $sql = "SHOW COLUMNS FROM " . $tabela;
        $query = $this->conn->query($sql);
        $colunas = $query->fetchAll(PDO::FETCH_OBJ);
        $txt = "";

        foreach ($colunas as $coluna) {
            $txt .= $coluna->Field . ",";
        }

        return rtrim($txt, ','); // More concise way to remove the trailing comma
    }

    public function salvar($obj)
    {
        $this->conexao();
        $tabela = $this->selecionarTabela(get_class($obj));
        $colunas = $this->selecionarColunas($tabela);
        $nome = $obj->getNome();
        $idade = $obj->getIdade();

        $sql = "INSERT INTO " . $tabela . " (" . $colunas . ") VALUES (null, :nome, :idade)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':idade', $idade);
        $stmt->execute();

        echo $sql;
    }

    public function excluir($id, $tabela)
    {
        $this->conexao();
        $sql = "DELETE FROM " . $tabela . " WHERE id = :id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
    }

    public function lista($tabela)
    {
        $this->conexao();
        $sql = "SELECT * FROM " . $tabela;
        $query = $this->conn->query($sql);
        $dados = $query->fetchAll(PDO::FETCH_OBJ);
        $txt = "";

        foreach ($dados as $dado) {
            $txt .= "id: " . $dado->id;
            $txt .= " Nome: " . $dado->nome;
            $txt .= " - <a href='../fwkSis/FWK.php?excluir=" . $dado->id . "&tabela=" . $tabela . "'>excluir</a>";
            $txt .= " <hr> ";
        }
        return $txt;
    }
}
