<?php
include "../fwkSis/FWK.php";
include "../model/Pessoas.php";
include "../model/Animal.php";

$fwk = new FWK();

for ($i = 0; $i < 50; $i++) {

    $pessoa = new Pessoa();
    $pessoa->setNome("Pessoa" . $i);
    $pessoa->setIdade(rand(20, 60));

    // Create a new Animal instance
    $animal = new Animal();
    $animal->setRaca("Vira-latas");
    $animal->setPeso(3);
    $animal->setTamanho(10);


    $fwk->salvar($pessoa);
    $fwk->salvar($animal);
}
?>
