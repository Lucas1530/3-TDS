<?php
include "../fwkSis/FWK.php";
include "../model/Pessoas.php";

$fwk=new FWK();

echo $fwk->lista("pessoas");